<?php 
    require_once('helper.php');

    $query = "SELECT * FROM data_user";
    $sql = mysqli_query($db_connect, $query);

    if($sql){
        $result = array();
        while($row = mysqli_fetch_array($sql)){
            array_push($result, array(
                'username' => $row['username'],
                'phone_number' => $row['phone_number'],
                'kata_sandi' => $row['kata_sandi'],
            ));
        }
        echo json_encode(array($result));
    }
?>