<?php 
$konek = mysqli_connect("localhost","root","");

$database = mysqli_select_db($konek, "barang_db");
?>