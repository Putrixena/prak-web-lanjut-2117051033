<?php 

    require_once('helper.php');
    parse_str(file_get_contents('php://input'), $value);

    $pass = $value['kata_sandi'];
    $phone_number = $value['phone_number'];
    $username = $value['username'];

    $query = "UPDATE data_user SET username='$username', phone_number=$phone_number WHERE kata_sandi='$pass'";
    $sql = mysqli_query($db_connect, $query);

    if($sql){
        echo json_encode(array('message' => 'Update!'));
    } else {
        echo json_encode(array('message' => 'GAGAL UPDATE!'));
    }
?>